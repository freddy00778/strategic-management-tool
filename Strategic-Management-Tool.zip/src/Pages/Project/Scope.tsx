const Scope = () => {
  return <div>Scope</div>;
};

export default Scope;
