const Lessons = () => {
  return <div>Lessons</div>;
};

export default Lessons;
