const TransitionCurve = () => {
  return <div>TransitionCurve</div>;
};

export default TransitionCurve;
