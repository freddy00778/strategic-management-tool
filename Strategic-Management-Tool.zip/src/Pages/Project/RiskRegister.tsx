const RiskRegister = () => {
  return <div>RiskRegister</div>;
};

export default RiskRegister;
