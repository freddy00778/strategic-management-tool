const KeyChanges = () => {
  return <div>KeyChanges</div>;
};

export default KeyChanges;
