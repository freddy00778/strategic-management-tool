const IssueRegister = () => {
  return <div>IssueRegister</div>;
};

export default IssueRegister;
