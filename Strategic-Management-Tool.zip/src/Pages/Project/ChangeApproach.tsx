const ChangeApproach = () => {
  return <div>ChangeApproach</div>;
};

export default ChangeApproach;
