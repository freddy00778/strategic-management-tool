const Budget = () => {
  return <div>Budget</div>;
};

export default Budget;
