const DecisionRegister = () => {
  return <div>DecisionRegister</div>;
};

export default DecisionRegister;
