const CaseChange = () => {
  return <div>CaseChange</div>;
};

export default CaseChange;
