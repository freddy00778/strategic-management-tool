const ProjectInfoForm = () => {
  return <div>Project Information</div>;
};

export default ProjectInfoForm;
