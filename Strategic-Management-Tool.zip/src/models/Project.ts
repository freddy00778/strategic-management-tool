export interface ProjectProps {
  id: string;
  title: string;
  name: string;
}
