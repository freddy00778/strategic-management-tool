export interface NavLinksProps {
  id: string;
  title: string;
  image: string;
  route: string;
}
